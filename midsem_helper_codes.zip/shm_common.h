
#define SIZE 84 // size of array
#define SHM_KEY 1234 // key for the shared memory segment shared among P0, HP1, and HP2

int *arr; //this is the return address by shared mmemory attach function and so it can serve as the base address of array

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/shm.h>
#include <errno.h>
#include <stdint.h> 
#include <time.h> 
#include <stdbool.h>
