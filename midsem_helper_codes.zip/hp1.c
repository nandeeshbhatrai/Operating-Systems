/* Helper Process P1  */

#include "shm_common.h"

int main(){
	/*
		YOUR CODE HERE
	*/
	
	// detach
    if (shmdt(arr) == -1) {
        fprintf(stderr, "shmdt failed\n");
        fprintf(stderr, "Error: %s\n", strerror(errno)); // Print error using strerror
        exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);
}
