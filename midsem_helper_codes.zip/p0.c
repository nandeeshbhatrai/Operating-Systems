/* Process P0  */

#include "shm_common.h"

//this function just stores a valid solution
void store_a_valid_solution(){
	// Store the values starting from index 1
	arr[0] = 5; arr[1] = 3; arr[2] = 4; arr[3] = 6; arr[4] = 7; arr[5] = 8; arr[6] = 9; arr[7] = 1; arr[8] = 2;
	arr[9] = 6; arr[10] = 7; arr[11] = 2; arr[12] = 1; arr[13] = 9; arr[14] = 5; arr[15] = 3; arr[16] = 4; arr[17] = 8;
	arr[18] = 1; arr[19] = 9; arr[20] = 8; arr[21] = 3; arr[22] = 4; arr[23] = 2; arr[24] = 5; arr[25] = 6; arr[26] = 7;
	arr[27] = 8; arr[28] = 5; arr[29] = 9; arr[30] = 7; arr[31] = 6; arr[32] = 1; arr[33] = 4; arr[34] = 2; arr[35] = 3;
	arr[36] = 4; arr[37] = 2; arr[38] = 6; arr[39] = 8; arr[40] = 5; arr[41] = 3; arr[42] = 7; arr[43] = 9; arr[44] = 1;
	arr[45] = 7; arr[46] = 1; arr[47] = 3; arr[48] = 9; arr[49] = 2; arr[50] = 4; arr[51] = 8; arr[52] = 5; arr[53] = 6;
	arr[54] = 9; arr[55] = 6; arr[56] = 1; arr[57] = 5; arr[58] = 3; arr[59] = 7; arr[60] = 2; arr[61] = 8; arr[62] = 4;
	arr[63] = 2; arr[64] = 8; arr[65] = 7; arr[66] = 4; arr[67] = 1; arr[68] = 9; arr[69] = 6; arr[70] = 3; arr[71] = 5;
	arr[72] = 3; arr[73] = 4; arr[74] = 5; arr[75] = 2; arr[76] = 8; arr[77] = 6; arr[78] = 1; arr[79] = 7; arr[80] = 9;
}

// Function to check if an array "arr1" of size 9 contains all digits from 1 to 9. It is assumed that array elements are from 1 to 9.
bool check_1_to_9(int arr1[]){
    bool digits[9] = {false}; //this array records presence of a digit
    
    for (int i = 0; i < 9; i++) {
        if (digits[arr1[i] - 1]) {
            return false; // a duplicate, all digits will not be present
        }
        digits[arr1[i] - 1] = true; // record the presence of this digit
    }
    return true; // all digits from 1 to 9 are found
}

//this function prints the Sudoku
void print_sudoku(){
	printf("\t\tPrinting Sudoku\n");
	int ind = 0;
	for(int i = 0; i < 9; i++){
		for(int j = 0; j < 9; j++){
			printf("%d\t", arr[ind++]);
		}
		printf("\n");
	}
	printf("\n");
}

int main(){
	/*
		YOUR CODE HERE
	*/
		
	// Create an array of 81 random numbers in the range 1-9
    for (int i = 0; i < 81; i++) {
        arr[i] = rand() % 9 + 1;
    }
    
    //Uncomment following function to store a valid solution in array
    //store_a_valid_solution();
        
    //uncomment to print Sudoku
    //print_sudoku();
	
	/*
		YOUR CODE HERE
	*/
    
	
	// detach
    if (shmdt(arr) == -1) {
        fprintf(stderr, "shmdt failed\n");
        fprintf(stderr, "Error: %s\n", strerror(errno)); // Print error using strerror
        exit(EXIT_FAILURE);
    }
    
    // Delete
    if (shmctl(shmid, IPC_RMID, 0) == -1) { //Assuming shmid is the shared memeroy identifier
        fprintf(stderr, "shmctl(IPC_RMID) failed\n");
        fprintf(stderr, "Error: %s\n", strerror(errno)); // Print error using strerror
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}
