#include<bits/stdc++.h>
using namespace std;

void print_queue(queue<tuple<int , int , string>> ready_queue){
    while(!ready_queue.empty()){
        cout << get<2>(ready_queue.front()) << ' ';
        ready_queue.pop();
    }
    cout << '\n';
}

void FCFS(queue<tuple<int , int , string>> process , int n , int max_time){
    queue<tuple<int , int , string>> ready_queue;
    string status = "Idle";
    int end = 0;
    for(int time = 0; time <= max_time; ++time){
        while(!process.empty() && time == get<0>(process.front())){ // add arrivals
            cout << "EVENT: New process arrived at Time = " << time << "\n";
            ready_queue.push(process.front());
            if(status == "Idle"){
                status = get<2>(ready_queue.front());
                end = time + get<1>(ready_queue.front());
                ready_queue.pop();
            }
            cout << "Ready Queue: "; print_queue(ready_queue);
            cout << "Status = " << status << '\n';
            process.pop();
            cout << "------------------------\n";
        }
        if(time == end){
            cout << "EVENT: Process Terminated at Time = " << time << "\n";
            if(!ready_queue.empty()){
                status = get<2>(ready_queue.front());
                end = time + get<1>(ready_queue.front());
                ready_queue.pop();
            }else{
                status = "Idle";
            }
            cout << "Ready Queue: "; print_queue(ready_queue);
            cout << "Status = " << status << '\n';
            cout << "---------------------------\n";
        }
    }
}

int main(){
    ifstream processes("process_file");
    if (!processes.is_open()) {
        cerr << "No processes!" << endl;
        return 1;
    }
    int n;
    processes >> n;
    cout << "Number of processes = " << n << '\n';
    queue<tuple<int , int , string>> process;

    int max_time = 0;

    for(int i =0; i < n; ++i){
        int arrival , burst;
        string name = "P" + to_string(i+1);
        processes >> arrival >> burst;
        process.push({arrival , burst , name});
        max_time = max(max_time , arrival);
        max_time += burst;
    }

    FCFS(process , n , max_time);
    return 0;
}