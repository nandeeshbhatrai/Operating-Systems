#include <stdio.h>

int func(){
	return(0);
}


int main(){

	int n = 1;
	for (int i=0; i < n; i++){
    		func();
  	}

  return 0;
}
